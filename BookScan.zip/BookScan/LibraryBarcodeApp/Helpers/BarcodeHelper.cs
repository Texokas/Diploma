using System.Drawing;
using System.IO;
using ZXing;

namespace LibraryBarcodeApp.Helpers;

public static class BarcodeHelper
{
    public static string? DecodeBarcodeFromImage(string imagePath)
    {
        if (string.IsNullOrWhiteSpace(imagePath) || !File.Exists(imagePath))
        {
            return null;
        }

        using var bitmap = (Bitmap)Image.FromFile(imagePath);
        var reader = new BarcodeReaderGeneric();
        var result = reader.Decode(bitmap);
        return result?.Text;
    }
}
